package healthsignz.com.viewpagerv2.Activity;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;



import java.util.ArrayList;
import java.util.List;

import healthsignz.com.viewpagerv2.Adapters.ViewPagerAdapterMain;
import healthsignz.com.viewpagerv2.Interfaces.SetFadingBackground;
import healthsignz.com.viewpagerv2.Model.TimerDetail;
import healthsignz.com.viewpagerv2.R;


public class WelcomeActivity extends AppCompatActivity {
    static public ViewPager viewPager ;
    static public ViewPagerAdapterMain viewPagerAdapter ;
    List<TimerDetail> sessionList = new ArrayList<>();
    RadioGroup radioGroup ;
    int[] radioGroupIds ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_welcome);
        viewPager = (ViewPager)findViewById(R.id.viewPager);
        radioGroup = (RadioGroup)findViewById(R.id.radiogroup);

        viewPager.setClipToPadding(false);
        viewPager.setPadding(150,0,150,0);
        viewPager.setPageMargin(50);
        sessionList.add(new TimerDetail("One",1000,10000,1000,1));
        sessionList.add(new TimerDetail("Two",2000,20000,2000,2));
        sessionList.add(new TimerDetail("Three",3000,30000,3000,3));
        sessionList.add(new TimerDetail("Four",4000,40000,4000,4));
      /*  sessionList.add(new TimerDetail("Five",5000,50000,5000,5));
        sessionList.add(new TimerDetail("Six",6000,60000,6000,6));*/
        if(sessionList==null)
            sessionList = new ArrayList<>();
        addRadioButtons(sessionList.size()+1);
        viewPagerAdapter = new ViewPagerAdapterMain(getSupportFragmentManager(),sessionList);
        viewPager.setAdapter(viewPagerAdapter);
        radioGroup.check(radioGroupIds[0]);
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                SetFadingBackground background = (SetFadingBackground)viewPagerAdapter.instantiateItem(viewPager,position);
                background.setFadeDisable();
                radioGroup.check(radioGroupIds[position]);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
               if(state==viewPager.SCROLL_STATE_DRAGGING){
                    SetFadingBackground background = (SetFadingBackground)viewPagerAdapter.instantiateItem(viewPager,viewPager.getCurrentItem());
                    background.setFadeEnable();

                }

                if(state==viewPager.SCROLL_STATE_IDLE){
                    SetFadingBackground background = (SetFadingBackground)viewPagerAdapter.instantiateItem(viewPager,viewPager.getCurrentItem());
                    background.setFadeDisable();
                }
            }
        });


    }

    public void addRadioButtons(int number) {
        radioGroupIds = new int[number];
        for (int row = 0; row < 1; row++) {
            RadioGroup ll = new RadioGroup(this);
            ll.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 1; i <= number; i++) {
                RadioButton rdbtn = new RadioButton(this);
                rdbtn.setGravity(Gravity.CENTER );
                rdbtn.setId((row * 2) + i);
                rdbtn.setClickable(false);
                rdbtn.setScaleX(0.7f);
                rdbtn.setScaleY(0.7f);
                radioGroupIds[i-1]=(row * 2) + i ;
                ll.addView(rdbtn);
            }
            radioGroup.addView(ll);
        }
    }
}
