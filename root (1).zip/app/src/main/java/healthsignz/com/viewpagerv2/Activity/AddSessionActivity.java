package healthsignz.com.viewpagerv2.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import healthsignz.com.viewpagerv2.R;


public class AddSessionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_session);
    }
    

    public void setBreakTime(int min, int secs) {
    }

    public void setExcerciseTime(int min, int secs) {
    }

    public void setRounds(int rounds) {
    }

    public void setWarmupTime(int min, int secs) {
    }
}
