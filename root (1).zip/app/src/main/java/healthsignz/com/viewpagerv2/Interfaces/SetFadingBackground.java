package healthsignz.com.viewpagerv2.Interfaces;

/**
 * Created by devuser on 04-05-2016.
 */
public interface SetFadingBackground {
    void setFadeEnable();
    void setFadeDisable();
}
