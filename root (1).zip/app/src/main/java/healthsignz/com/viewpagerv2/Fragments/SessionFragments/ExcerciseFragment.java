package healthsignz.com.viewpagerv2.Fragments.SessionFragments;

import android.graphics.Color;
import android.os.Bundle;

import healthsignz.com.viewpagerv2.Activity.MainActivity;
import healthsignz.com.viewpagerv2.Interfaces.PageSelectedListener;
import healthsignz.com.viewpagerv2.Model.TimerDetail;

public class ExcerciseFragment extends SessionFragment implements PageSelectedListener {

    TimerDetail mTimerDetail ;

    public static ExcerciseFragment newInstance(TimerDetail timerDetail ,String message) {
        Bundle args = new Bundle();
        args.putString("message", message);
        ExcerciseFragment fragment = new ExcerciseFragment();
        fragment.mTimerDetail = timerDetail ;
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public long getTime() {
        return mTimerDetail.getExcerciseTime() ;
    }

    @Override
    public void nevigation() {
        mTimerDetail.round = mTimerDetail.round - 1 ;

        if(mTimerDetail.round!=0)
            MainActivity.viewPager.setCurrentItem(2,true);
        else
            MainActivity.viewPager.setCurrentItem(3,true);
    }

    @Override
    public TimerDetail getTimerDetail() {
        return mTimerDetail ;
    }

    @Override
    public void setBackgroundColor() {
        mRelativeLayout.setBackgroundColor(Color.parseColor("#4FC3F7"));
    }

    @Override
    public void setBackgroundColor(int color) {
        mRelativeLayout.setBackgroundColor(color);

    }
}
