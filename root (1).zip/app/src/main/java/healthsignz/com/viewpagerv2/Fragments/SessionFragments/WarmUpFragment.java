package healthsignz.com.viewpagerv2.Fragments.SessionFragments;

import android.graphics.Color;
import android.os.Bundle;

import healthsignz.com.viewpagerv2.Activity.MainActivity;
import healthsignz.com.viewpagerv2.Model.TimerDetail;


public class WarmUpFragment extends SessionFragment {
    TimerDetail mTimerDetail ;

    public static WarmUpFragment newInstance(TimerDetail timerDetail,String message){
        WarmUpFragment fragment = new WarmUpFragment();
        fragment.mTimerDetail = timerDetail ;
        Bundle bundle = new Bundle();
        bundle.putString("message",message);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public long getTime() {
        return mTimerDetail.getWarmupTime();
    }

    @Override
    public void nevigation() {
        MainActivity.viewPager.setCurrentItem(1,true);
    }

    @Override
    public TimerDetail getTimerDetail() {
        return mTimerDetail ;
    }

    @Override
    public void setBackgroundColor() {
        mRelativeLayout.setBackgroundColor(Color.parseColor("#FDD835"));
        if(MainActivity.viewPager.getCurrentItem()==0)
            startTimerNow();
    }

    @Override
    public void setBackgroundColor(int color) {
        mRelativeLayout.setBackgroundColor(color);

    }

}