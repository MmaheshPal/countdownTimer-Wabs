package healthsignz.com.viewpagerv2.Fragments.SessionFragments;

import android.graphics.Color;
import android.os.Bundle;

import healthsignz.com.viewpagerv2.Activity.MainActivity;
import healthsignz.com.viewpagerv2.Model.TimerDetail;
import healthsignz.com.viewpagerv2.Utils.Constants;


public class BreakFragment extends SessionFragment {


    TimerDetail mTimerDetail ;

    public static BreakFragment newInstance(TimerDetail timerDetail,String message){
        BreakFragment fragment = new BreakFragment();
        fragment.mTimerDetail = timerDetail ;
        Bundle bundle = new Bundle();
        bundle.putString("message", message);
        fragment.setArguments(bundle);
        return fragment ;
    }

    @Override
    public long getTime() {
        return mTimerDetail.getBreakTime();
    }

    @Override
    public void nevigation() {
        MainActivity.viewPager.setCurrentItem(1,true);
    }

    @Override
    public TimerDetail getTimerDetail() {
        return mTimerDetail ;
    }

    @Override
    public void setBackgroundColor() {
        mRelativeLayout.setBackgroundColor(Color.parseColor("#BA68C8"));
    }

    @Override
    public void setBackgroundColor(int color) {
        mRelativeLayout.setBackgroundColor(color);

    }
}

