package healthsignz.com.viewpagerv2.Fragments.SessionFragments;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ToggleButton;

import healthsignz.com.viewpagerv2.Interfaces.PageSelectedListener;
import healthsignz.com.viewpagerv2.Model.TimerDetail;


public class SuccessFragment extends SessionFragment implements PageSelectedListener {

    TimerDetail mTimerDetail;
    public static SuccessFragment newInstance(TimerDetail timerDetail,String message){
        SuccessFragment fragment = new SuccessFragment();
        fragment.mTimerDetail = timerDetail ;
        Bundle bundle = new Bundle();
        bundle.putString("message", message);
        fragment.setArguments(bundle);
        return fragment ;
    }


    @Override
    public void startTimerNow() {

        mTextViewRound.setVisibility(View.GONE);
        mTextViewTitile.setText("Success");
        mTextViewTitile.setVisibility(View.VISIBLE);
        mTextViewRoundLabel.setText("Completed");
    }

    @Override
    public  long getTime() {
        return 0 ;
    }

    @Override
    public void nevigation() {
    }

    @Override
    public void onPlaybackControlChange(ToggleButton toggleButton) {
        Intent intent = getActivity().getIntent();
        getActivity().finish();
        startActivity(intent);
    }

    @Override
    public TimerDetail getTimerDetail() {
        return mTimerDetail ;
    }

    @Override
    public void setBackgroundColor() {
        mRelativeLayout.setBackgroundColor(Color.parseColor("#607D8B"));
    }

    @Override
    public void setBackgroundColor(int color) {
        mRelativeLayout.setBackgroundColor(color);

    }
}
