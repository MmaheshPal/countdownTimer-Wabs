package healthsignz.com.viewpagerv2.Utils;

import android.content.Context;
import android.graphics.Typeface;


public class Constants {

    static Typeface mFont  ;
    public static final int HALF_SECOND = 500 ;
    public static final int ONE_SECOND = 1000 ;

    public static Typeface getTypeface(Context context, String typeface) {
        typeface = "fonts/"+typeface+".ttf" ;
        mFont = Typeface.createFromAsset(context.getAssets(), typeface);
        return mFont;
    }
}
