package healthsignz.com.viewpagerv2.Model;

/**
 * Created by devuser on 27-04-2016.
 */
public class TimerDetail {


    private String exerciseName ;
    private long breakTime ;
    private long exerciseTime ;
    private long warmupTime ;
    public int round ;
    public int totalRound ;

    public TimerDetail(String exerciseName ,long warmupTime, long exerciseTime, long breakTime, int round) {
        this.exerciseName = exerciseName  ;
        this.warmupTime = warmupTime;
        this.exerciseTime = exerciseTime;
        this.breakTime = breakTime;
        this.round = round ;
        totalRound = round ;
    }

    public String getExcerciseName() {
        return exerciseName;
    }

    public void setExcerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public long getWarmupTime() {
        return warmupTime;
    }

    public void setWarmupTime(long warmupTime) {
        this.warmupTime = warmupTime;
    }

    public long getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(long breakTime) {
        this.breakTime = breakTime;
    }

    public long getExcerciseTime() {
        return exerciseTime;
    }

    public void setExcerciseTime(long exerciseTime) {
        this.exerciseTime = exerciseTime;
    }
}
