package healthsignz.com.viewpagerv2.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;


import java.util.ArrayList;
import java.util.List;

import healthsignz.com.viewpagerv2.Fragments.SessionFragments.SessionPageFragment;
import healthsignz.com.viewpagerv2.Model.TimerDetail;


/**
 * Created by devuser on 04-05-2016.
 */
public class ViewPagerAdapterMain extends FragmentStatePagerAdapter {
    List<TimerDetail> sessionList = new ArrayList<>();

    public ViewPagerAdapterMain(FragmentManager fm, List<TimerDetail> sessionList) {
        super(fm);
        this.sessionList = sessionList ;
    }

    @Override
    public Fragment getItem(int position) {
        if(position==sessionList.size())
            return SessionPageFragment.newInstance(null);


        return SessionPageFragment.newInstance(sessionList.get(position));
    }

    @Override
    public int getCount() {
        return sessionList.size()+1;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }

}
