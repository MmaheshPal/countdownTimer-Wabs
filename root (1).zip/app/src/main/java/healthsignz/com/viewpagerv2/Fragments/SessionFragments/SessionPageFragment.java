package healthsignz.com.viewpagerv2.Fragments.SessionFragments;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;


import java.util.concurrent.TimeUnit;

import healthsignz.com.viewpagerv2.Activity.AddSessionActivity;
import healthsignz.com.viewpagerv2.Activity.WelcomeActivity;
import healthsignz.com.viewpagerv2.Interfaces.SetFadingBackground;
import healthsignz.com.viewpagerv2.Model.TimerDetail;
import healthsignz.com.viewpagerv2.R;


/**
 * Created by devuser on 04-05-2016.
 */
public class SessionPageFragment extends Fragment implements SetFadingBackground {
    final String FADE_BACKGROUND = "#90757575" ;
    TextView mTextViewBreakTime ;
    TextView mTextViewExcerciseTime ;
    TextView mTextViewWarmUpTime ;
    TextView mTextViewRounds ;
    TextView mTextViewExcerciseName ;
    TextView mTextViewAddSession ;
    WelcomeActivity mainactivity ;
    TimerDetail mTimerDetail ;
    LinearLayout mLinearLayoutInfo , mLinearLayoutStart ,mLinearLayoutMain ;
    FrameLayout mFramelayout ;

    public static SessionPageFragment newInstance(TimerDetail mTimerDetail) {
        SessionPageFragment fragment = new SessionPageFragment();
        fragment.mTimerDetail = mTimerDetail ;
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_session_list,container,false);

        mLinearLayoutMain = (LinearLayout)view.findViewById(R.id.linearlayout_main);
        mTextViewBreakTime = (TextView) view.findViewById(R.id.textview_breakTime);
        mTextViewExcerciseTime = (TextView) view.findViewById(R.id.textview_exerciseTime);
        mTextViewWarmUpTime = (TextView) view.findViewById(R.id.textview_preparationTime);
        mTextViewRounds = (TextView) view.findViewById(R.id.textview_number_of_rounds);
        mTextViewExcerciseName = (TextView)view.findViewById(R.id.textview_exercise_name);
        mFramelayout = (FrameLayout) view.findViewById(R.id.framelayout_fade);
        mLinearLayoutInfo = (LinearLayout)view.findViewById(R.id.layout_info);
        mLinearLayoutStart = (LinearLayout)view.findViewById(R.id.layout_start_edit);
        mTextViewAddSession = (TextView)view.findViewById(R.id.textview_add_session);
        mTextViewAddSession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), AddSessionActivity.class);
                startActivity(intent);
            }
        });
        if(mTimerDetail==null){
            mLinearLayoutMain.setVisibility(View.GONE);
            mTextViewAddSession.setVisibility(View.VISIBLE);
            mFramelayout.setVisibility(View.GONE);
            return view ;
        }else {
            mFramelayout.setVisibility(View.VISIBLE);
            mLinearLayoutMain.setVisibility(View.VISIBLE);
            mTextViewAddSession.setVisibility(View.GONE);
        }

        mTextViewExcerciseName.setText(mTimerDetail.getExcerciseName());
        mTextViewBreakTime.setText(getFormattedTime(mTimerDetail.getBreakTime()));
        mTextViewExcerciseTime.setText(getFormattedTime(mTimerDetail.getExcerciseTime()));
        mTextViewWarmUpTime.setText(getFormattedTime(mTimerDetail.getWarmupTime()));
        mTextViewRounds.setText(mTimerDetail.getRound()+"");

        mLinearLayoutInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mLinearLayoutInfo.getVisibility()==View.VISIBLE){
                    mLinearLayoutInfo.setVisibility(View.GONE);
                    mLinearLayoutStart.setVisibility(View.VISIBLE);
                    startCountdown();
                }
            }
        });


        return view ;
    }

    private void startCountdown() {
        new CountDownTimer(3000, 500) {

            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                mLinearLayoutInfo.setVisibility(View.VISIBLE);
                mLinearLayoutStart.setVisibility(View.GONE);
            }
        }.start();
    }

    private String getFormattedTime(long breakTime) {
        int mins = (int) TimeUnit.MILLISECONDS.toMinutes(breakTime);
        int secs = (int) (TimeUnit.MILLISECONDS.toSeconds(breakTime) -
                 TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(breakTime)));
                return  getFormattedMinSecs(mins,secs) ;
    }



    private String getFormattedMinSecs(int mins, int secs) {
        String minute ="",seconds = "";
        if(mins<10){
            minute = "0"+ mins;
        }else {
            minute = "" + mins ;
        }

        if(secs<10){
            seconds = "0"+secs ;
        }else {
            seconds = "" +secs;
        }

        return minute+":"+seconds;
    }


    @Override
    public void setFadeEnable() {
        mFramelayout.setBackgroundColor(Color.parseColor(FADE_BACKGROUND));
    }

    @Override
    public void setFadeDisable() {
        mFramelayout.setBackgroundResource(0);
    }
}
